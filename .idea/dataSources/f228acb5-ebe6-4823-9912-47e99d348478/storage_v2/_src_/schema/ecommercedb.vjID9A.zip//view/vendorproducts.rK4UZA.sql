create definer = root@localhost view vendorproducts as
select `ecommercedb`.`products`.`id`                AS `id`,
       `ecommercedb`.`products`.`vendor_id`         AS `vendor_id`,
       `ecommercedb`.`products`.`supplier_id`       AS `supplier_id`,
       `ecommercedb`.`products`.`category_id`       AS `category_id`,
       `ecommercedb`.`products`.`product_avatar`    AS `product_avatar`,
       `ecommercedb`.`products`.`name`              AS `name`,
       `ecommercedb`.`products`.`short_description` AS `short_description`,
       `ecommercedb`.`products`.`full_description`  AS `full_description`,
       `ecommercedb`.`products`.`slug`              AS `slug`,
       `ecommercedb`.`products`.`price`             AS `price`,
       `ecommercedb`.`products`.`qty`               AS `qty`,
       `ecommercedb`.`products`.`unit`              AS `unit`,
       `ecommercedb`.`products`.`created_at`        AS `created_at`,
       `ecommercedb`.`products`.`updated_at`        AS `updated_at`,
       `ecommercedb`.`categories`.`name`            AS `catName`,
       `ecommercedb`.`vendors`.`id`                 AS `venId`
from (((`ecommercedb`.`vendors` join `ecommercedb`.`products` on ((`ecommercedb`.`products`.`vendor_id` = `ecommercedb`.`vendors`.`id`))) join `ecommercedb`.`users` on ((`ecommercedb`.`vendors`.`user_id` = `ecommercedb`.`users`.`id`)))
         join `ecommercedb`.`categories` on ((`ecommercedb`.`products`.`category_id` = `ecommercedb`.`categories`.`id`)))
group by `ecommercedb`.`products`.`id`, `ecommercedb`.`categories`.`name`, `ecommercedb`.`vendors`.`id`;

