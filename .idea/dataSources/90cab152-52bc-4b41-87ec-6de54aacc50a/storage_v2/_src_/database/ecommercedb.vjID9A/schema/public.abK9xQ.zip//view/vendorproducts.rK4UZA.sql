create view vendorproducts(id, vendor_id, supplier_id, category_id, product_avatar, name, short_description,
                           full_description, slug, price, qty, unit, created_at, updated_at, catname) as
SELECT products.id,
       products.vendor_id,
       products.supplier_id,
       products.category_id,
       products.product_avatar,
       products.name,
       products.short_description,
       products.full_description,
       products.slug,
       products.price,
       products.qty,
       products.unit,
       products.created_at,
       products.updated_at,
       categories.name AS catname
FROM (((vendors
    JOIN products ON ((products.vendor_id = vendors.id)))
    JOIN users ON ((vendors.user_id = users.id)))
         JOIN categories ON ((products.category_id = categories.id)))
GROUP BY products.id, categories.name;

alter table vendorproducts
    owner to postgres;

